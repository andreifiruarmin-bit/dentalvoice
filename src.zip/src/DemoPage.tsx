import React from 'react';
import { motion } from 'motion/react';
import { 
  Send, 
  Bot, 
  X,
  Smartphone
} from 'lucide-react';
import { SERVICES, FAQ, ChatOption, TRAINING_DATA } from './types';
import { bookingService } from './services/bookingService';
import { format, addDays, isWeekend } from 'date-fns';
import { ro } from 'date-fns/locale';
import { cn } from './lib/utils';
import { Link } from 'react-router-dom';

type MessageType = 'bot' | 'user';

interface Message {
  id: string;
  type: MessageType;
  text: string;
  options?: (string | ChatOption)[];
  component?: React.ReactNode;
}

export default function DemoPage() {
  const [messages, setMessages] = React.useState<Message[]>([]);
  const [inputValue, setInputValue] = React.useState('');
  const [isTyping, setIsTyping] = React.useState(false);
  const [isChatOpen, setIsChatOpen] = React.useState(false);
  const hasGreeted = React.useRef(false);
  
  const [step, setStep] = React.useState<'initial' | 'service' | 'doctor_selection' | 'date' | 'date_selection' | 'time' | 'time_selection' | 'summary' | 'details_name' | 'details_phone' | 'verification' | 'edit_search' | 'edit_verify' | 'edit_confirm_details' | 'edit_cancel_confirm' | 'edit_keep_details' | 'edit_reschedule_date' | 'edit_reschedule_time' | 'confirmed' | 'exit_confirm' | 'call_confirm' | 'email_request'>('initial');
  const [previousStep, setPreviousStep] = React.useState<any>('initial');
  const [clinicConfig, setClinicConfig] = React.useState<any>(null);

  const [bookingData, setBookingData] = React.useState<{
    id?: string;
    service?: string;
    doctorId?: string;
    doctorName?: string;
    date?: string;
    isoDate?: string;
    time?: string;
    firstName?: string;
    lastName?: string;
    phone?: string;
    verificationCode?: string;
    skipName?: boolean;
  }>({});

  const [tempBooking, setTempBooking] = React.useState<any>(null);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const addMessage = (text: string, type: MessageType, options?: (string | ChatOption)[]) => {
    const newMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      text,
      options
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const botReply = async (text: string, options?: (string | ChatOption)[], nextStep?: any) => {
    setIsTyping(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsTyping(false);
    addMessage(text, 'bot', options);
    if (nextStep) {
      if (nextStep !== 'exit_confirm' && nextStep !== 'call_confirm') {
        setPreviousStep(step);
      }
      setStep(nextStep);
    }
  };

  const formatDateForDisplay = (dateStr: string) => {
    if (!dateStr || !dateStr.includes('-')) return dateStr;
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const [year, month, day] = parts;
    if (year.length !== 4) return dateStr;
    return `${day}-${month}-${year}`;
  };

  React.useEffect(() => {
    const loadConfig = async () => {
      try {
        const config = await bookingService.getConfig();
        setClinicConfig(config);
      } catch (e) {
        console.error("Failed to load clinic config:", e);
      }
    };
    loadConfig();

    if (!hasGreeted.current) {
      hasGreeted.current = true;
      botReply(
        "Bună ziua! Sunt Denti, asistentul virtual al clinicii Beautiful Smile. Cu ce vă pot ajuta astăzi?",
        ["Vreau o programare", "Editare programare efectuată", "Sună Clinica", "Întrebări frecvente"]
      );
    }
  }, []);

  const handleOptionClick = (option: string | ChatOption) => {
    if (typeof option === 'string') {
      handleUserInput(option);
    } else {
      addMessage(option.label, 'user');
      processInput(option.value);
    }
  };

  const handleUserInput = async (input: string) => {
    if (!input.trim()) return;
    addMessage(input, 'user');
    setInputValue('');
    processInput(input);
  };

  const processInput = async (input: string) => {
    const lowerInput = input.toLowerCase();

    if (lowerInput.includes('editare') || lowerInput === 'cmd_editare') {
      setStep('initial');
      setBookingData({});
      setTempBooking(null);
      botReply(
        "Sigur, vă pot ajuta cu gestionarea programării. Vă rog să introduceți numărul de telefon folosit la programare.",
        undefined,
        'edit_search'
      );
      return;
    }

    if (lowerInput.includes('sună clinica') || lowerInput === 'sună clinica') {
      const phone = clinicConfig?.clinicPhone || "0700 000 000";
      botReply(
        `Puteți contacta recepția clinicii noastre la numărul de telefon: ${phone}. Doriți să apelați acum?`,
        [{ label: "Da, apelează", value: "da_apeleaza", href: `tel:${phone.replace(/\s+/g, '')}` }, "Nu, revino la meniu"],
        'call_confirm'
      );
      return;
    }

    if (lowerInput.includes('meniu principal')) {
      setBookingData({});
      setTempBooking(null);
      setStep('initial');
      botReply("Cu ce vă mai pot ajuta?", ["Vreau o programare", "Editare programare efectuată", "Sună Clinica", "Întrebări frecvente"]);
      return;
    }

    if (step === 'initial') {
      const trainingMatch = TRAINING_DATA.find(item => 
        item.keywords.some(keyword => lowerInput.includes(keyword.toLowerCase()))
      );

      if (trainingMatch) {
        if (trainingMatch.nextStep === 'service') {
          setBookingData({});
          setTempBooking(null);
          const services = clinicConfig?.services || SERVICES;
          botReply(trainingMatch.answer, services.map((s: any) => s.name), 'service');
        } else if (trainingMatch.nextStep) {
          botReply(trainingMatch.answer, undefined, trainingMatch.nextStep as any);
        } else {
          botReply(trainingMatch.answer, ["Vreau o programare", "Meniu principal"]);
        }
        return;
      }

      if (lowerInput.includes('programare') || lowerInput.includes('booking') || lowerInput.includes('fac o programare')) {
        setBookingData({});
        setTempBooking(null);
        const services = clinicConfig?.services || SERVICES;
        botReply(
          "Excelent! Ce tip de serviciu doriți să rezervați?",
          services.map((s: any) => s.name),
          'service'
        );
      } else if (lowerInput.includes('unde') || lowerInput.includes('locație')) {
        botReply(FAQ[0].answer, ["Vreau o programare", "Alte întrebări"]);
      } else if (lowerInput.includes('întrebări') || lowerInput.includes('faq')) {
        botReply("Iată câteva informații utile:", FAQ.map(f => f.question));
      } else {
        const faqMatch = FAQ.find(f => lowerInput.includes(f.question.toLowerCase()));
        if (faqMatch) {
          botReply(faqMatch.answer, ["Vreau o programare", "Alte întrebări"]);
        } else {
          botReply("Îmi pare rău, nu am înțeles. Doriți să faceți o programare, să editați una existentă sau să sunați la clinică?", ["Vreau o programare", "Editare programare efectuată", "Sună Clinica", "Întrebări frecvente"]);
        }
      }
    } 
    
    else if (step === 'service') {
      const services = clinicConfig?.services || SERVICES;
      const service = services.find((s: any) => lowerInput.includes(s.name.toLowerCase()) || s.name.toLowerCase().includes(lowerInput));
      if (service) {
        setBookingData(prev => ({ ...prev, service: service.name }));
        const doctors = clinicConfig?.resources || [
          { id: 'any', name: 'Oricare medic disponibil' },
          { id: 'ionescu', name: 'Ion Ionescu' },
          { id: 'andreescu', name: 'Andrei Andreescu' },
          { id: 'simonescu', name: 'Simona Simonescu' }
        ];
        botReply(
          "Doriți o programare la un anumit medic sau doriți prima oră disponibilă la oricare dintre specialiștii noștri?",
          doctors.map((d: any) => ({ label: d.name, value: d.id })),
          'doctor_selection'
        );
      } else {
        botReply("Vă rog să alegeți unul dintre serviciile de mai sus.", services.map((s: any) => s.name));
      }
    }

    else if (step === 'doctor_selection') {
      const doctors = clinicConfig?.resources || [
        { id: 'any', name: 'Oricare medic disponibil' },
        { id: 'ionescu', name: 'Ion Ionescu' },
        { id: 'andreescu', name: 'Andrei Andreescu' },
        { id: 'simonescu', name: 'Simona Simonescu' }
      ];
      const selected = doctors.find((d: any) => lowerInput.includes(d.name.toLowerCase()) || d.id === lowerInput);
      if (selected) {
        setBookingData(prev => ({ ...prev, doctorId: selected.id, doctorName: selected.name }));
        const days: ChatOption[] = [];
        let current = new Date();
        while (days.length < 5) {
          current = addDays(current, 1);
          if (!isWeekend(current)) {
            days.push({
              label: format(current, 'EEEE, d MMMM', { locale: ro }),
              value: format(current, 'yyyy-MM-dd')
            });
          }
        }
        botReply(`Ați ales: ${selected.name}. Pe ce dată doriți să veniți?`, [...days, { label: "Altă dată", value: "Altă dată" }], 'date');
      } else {
        botReply("Vă rog să alegeți un medic sau prima oră disponibilă.");
      }
    }

    else if (step === 'date' || step === 'date_selection') {
      if (lowerInput === 'altă dată') {
        botReply("Vă rog să introduceți data dorită (ex: 15 Aprilie).");
        return;
      }
      
      const validation = bookingService.validateDate(input);
      if (validation.isValid) {
        setBookingData(prev => ({ 
          ...prev, 
          date: validation.formatted, 
          isoDate: validation.iso 
        }));

        setIsTyping(true);
        try {
          const slots = await bookingService.getAvailableSlots(validation.iso!, bookingData.doctorId, bookingData.service);
          setIsTyping(false);
          
          if (slots.length > 0) {
            botReply(
              `Am verificat calendarul clinicii. Pentru ${validation.formatted} iată orele disponibile:`, 
              [...slots, "Alege alta dată"], 
              'time'
            );
          } else {
            botReply(
              `Ne pare rău, dar nu mai sunt locuri disponibile pentru ${validation.formatted}. Vă rugăm să alegeți altă zi.`,
              ["Alege altă dată", "Meniu principal"],
              'date'
            );
          }
        } catch (error) {
          setIsTyping(false);
          botReply(
            "A apărut o eroare de conexiune la verificarea calendarului. Vă rugăm să încercați din nou.",
            ["Încearcă din nou", "Meniu principal"],
            'date'
          );
        }
      } else {
        botReply(validation.error || "Data nu este disponibilă. Vă rugăm să încercați din nou (ex: 15 Aprilie).");
      }
    }

    else if (step === 'time' || step === 'time_selection') {
      if (lowerInput.includes('alege alta dată') || lowerInput.includes('alege alta data')) {
        const days: ChatOption[] = [];
        let current = new Date();
        while (days.length < 5) {
          current = addDays(current, 1);
          if (!isWeekend(current)) {
            days.push({
              label: format(current, 'EEEE, d MMMM', { locale: ro }),
              value: format(current, 'yyyy-MM-dd')
            });
          }
        }
        botReply("Nicio problemă. Pe ce dată doriți să veniți?", [...days, { label: "Altă dată", value: "Altă dată" }], 'date');
        return;
      }
      setBookingData(prev => ({ ...prev, time: input }));
      botReply(
        `Am notat. Iată rezumatul programării:\n- Serviciu: ${bookingData.service || 'Serviciu selectat'}\n- Medic: ${bookingData.doctorName || 'Medic selectat'}\n- Dată: ${bookingData.date || 'Data selectată'}\n- Oră: ${input}\n\nDoriți să confirmați?`,
        ["Confirmă", "Modifică"],
        'summary'
      );
    }

    else if (step === 'edit_keep_details') {
      if (lowerInput.includes('da')) {
        setBookingData(prev => ({ 
          ...prev, 
          firstName: tempBooking?.firstName, 
          lastName: tempBooking?.lastName, 
          phone: tempBooking?.phone,
          skipName: true 
        }));
        botReply(
          "Perfect. Haideți să facem noua programare. Ce tip de serviciu doriți să rezervați?",
          SERVICES.map(s => s.name),
          'service'
        );
      } else {
        setBookingData(prev => ({ ...prev, skipName: false }));
        botReply(
          "Am înțeles. Haideți să facem noua programare. Ce tip de serviciu doriți să rezervați?",
          SERVICES.map(s => s.name),
          'service'
        );
      }
    }

    else if (step === 'summary') {
      if (lowerInput.includes('confirm')) {
        setIsTyping(true);
        try {
          const slots = await bookingService.getAvailableSlots(bookingData.isoDate!, bookingData.doctorId, bookingData.service);
          setIsTyping(false);
          
          if (!slots.includes(bookingData.time!)) {
            botReply(
              "Ne pare rău, dar acest interval s-a ocupat între timp. Vă rugăm să alegeți altă oră.",
              [...slots, "Alege alta dată"],
              'time'
            );
            return;
          }

          if (bookingData.skipName) {
            const code = await bookingService.sendVerificationCode(bookingData.phone!);
            setBookingData(prev => ({ ...prev, verificationCode: code }));
            botReply(`Perfect! V-am trimis un cod de verificare prin WhatsApp la numărul ${bookingData.phone}. Vă rog să îl introduceți aici pentru a finaliza modificarea.`, ["Retrimite codul"], 'verification');
          } else {
            botReply("Perfect! Vă rog să introduceți Numele și Prenumele dumneavoastră.", undefined, 'details_name');
          }
        } catch (error) {
          setIsTyping(false);
          botReply("A apărut o eroare la verificarea disponibilității. Vă rugăm să încercați din nou.", ["Confirmă", "Modifică"]);
        }
      } else {
        const services = clinicConfig?.services || SERVICES;
        botReply("Nicio problemă. Ce tip de serviciu doriți să rezervați?", services.map((s: any) => s.name), 'service');
      }
    }

    else if (step === 'details_name') {
      const parts = input.split(' ');
      if (parts.length < 2) {
        botReply("Vă rog să introduceți atât Numele cât și Prenumele (ex: Popescu Ion).");
        return;
      }
      setBookingData(prev => ({ ...prev, lastName: parts[0], firstName: parts.slice(1).join(' ') }));
      botReply("Mulțumesc! Acum vă rog să introduceți numărul de telefon.");
      setStep('details_phone');
    }

    else if (step === 'details_phone') {
      const digitCount = input.replace(/\D/g, '').length;
      if (digitCount >= 9 && digitCount <= 13) {
        const sanitized = bookingService.sanitizePhone(input);
        setBookingData(prev => ({ ...prev, phone: sanitized }));
        setIsTyping(true);
        const code = await bookingService.sendVerificationCode(sanitized);
        setIsTyping(false);
        setBookingData(prev => ({ ...prev, verificationCode: code }));
        botReply(`V-am trimis un cod de verificare prin SMS/WhatsApp la numărul ${input}. (Simulare: Codul este ${code}). Vă rog să îl introduceți aici pentru validare.`);
        setStep('verification');
      } else {
        botReply("Vă rugăm să introduceți un număr de telefon valid (între 9 și 14 cifre).");
      }
    }

    else if (step === 'verification') {
      if (lowerInput.includes('retrimit')) {
        const code = await bookingService.sendVerificationCode(bookingData.phone!);
        setBookingData(prev => ({ ...prev, verificationCode: code }));
        botReply(`V-am retrimis un cod nou la numărul ${bookingData.phone}. Vă rog să îl introduceți aici.`);
        return;
      }
      if (input === bookingData.verificationCode) {
        try {
          setIsTyping(true);
          const result = await bookingService.createBooking({
            date: bookingData.isoDate!,
            displayDate: bookingData.date!,
            time: bookingData.time!,
            service: bookingData.service!,
            firstName: bookingData.firstName!,
            lastName: bookingData.lastName!,
            phone: bookingData.phone!,
            doctorId: bookingData.doctorId!
          });
          setIsTyping(false);

          const assignedText = (result as any).assignedMessage ? `\n\n👨‍⚕️ ${(result as any).assignedMessage}` : '';

          botReply(
            `✅ Felicitări, ${bookingData.firstName} ${bookingData.lastName}! Programarea dumneavoastră a fost înregistrată cu succes la ${result.doctorName || bookingData.doctorName}, ${bookingData.date} la ora ${bookingData.time}.${assignedText}\n\n📱 Recepția a fost notificată, iar mesajul de confirmare a fost trimis pe WhatsApp.\n\nCu ce vă mai pot ajuta?`,
            ["Trimite Programarea pe Email", "Vreau o programare", "Editare programare efectuată", "Închide"],
            'confirmed'
          );
        } catch (error: any) {
          setIsTyping(false);
          const errorMsg = error.message?.includes('Failed to fetch') 
            ? "A apărut o eroare de conexiune. Vă rugăm să încercați din nou."
            : error.message || "Slotul a fost ocupat între timp";
            
          botReply(
            `⚠️ Ne pare rău, dar a apărut o problemă: ${errorMsg}. Vă rugăm să alegeți altă oră.`,
            ["Alege altă oră", "Meniu principal"],
            'time'
          );
        }
      } else {
        botReply("Codul introdus este indisponibil. Vă rog să încercați din nou sau să cereți un alt cod.", ["Retrimite codul"]);
      }
    }

    else if (step === 'edit_search') {
      if (lowerInput.includes('schimbă numărul') || lowerInput.includes('încearcă din nou')) {
        botReply("Sigur. Vă rog să introduceți numărul de telefon folosit la programare.");
        return;
      }
      const digitCount = input.replace(/\D/g, '').length;
      if (digitCount >= 9 && digitCount <= 13) {
        const sanitized = bookingService.sanitizePhone(input);
        setIsTyping(true);
        const booking = await bookingService.findBookingByPhone(sanitized);
        setIsTyping(false);
        if (booking) {
          setTempBooking(booking);
          setIsTyping(true);
          const code = await bookingService.sendVerificationCode(sanitized);
          setIsTyping(false);
          setBookingData(prev => ({ ...prev, phone: sanitized, verificationCode: code }));
          botReply(
            `Am găsit o programare activă. Pentru securitate, v-am trimis un cod de verificare la numărul ${input}. (Simulare: Codul este ${code}). Vă rog să îl introduceți aici.`,
            ["Retrimite codul"],
            'edit_verify'
          );
        } else {
          botReply("Nu am găsit nicio programare activă pentru acest număr de telefon. Doriți să schimbați numărul?", ["Schimbă numărul de telefon", "Meniu principal"]);
        }
      } else {
        botReply("Vă rugăm să introduceți un număr de telefon valid (între 9 și 14 cifre).");
      }
    }

    else if (step === 'edit_verify') {
      if (lowerInput.includes('retrimit')) {
        const code = await bookingService.sendVerificationCode(bookingData.phone!);
        setBookingData(prev => ({ ...prev, verificationCode: code }));
        botReply(`V-am retrimis un cod nou la numărul ${bookingData.phone}. Vă rog să îl introduceți aici.`);
        return;
      }
      if (input === bookingData.verificationCode) {
        botReply(
          `Verificare reușită! Am găsit programarea pe numele ${tempBooking.firstName} ${tempBooking.lastName} pentru data de ${formatDateForDisplay(tempBooking.date)} la ora ${tempBooking.time}.\n\nSunt corecte aceste date?`,
          ["Da, sunt corecte", "Nu, sunt greșite", "Meniu principal"],
          'edit_confirm_details'
        );
      } else {
        botReply("Codul introdus este indisponibil. Vă rog să încercați din nou.", ["Retrimite codul"]);
      }
    }

    else if (step === 'edit_confirm_details') {
      if (lowerInput.includes('editează')) {
        await bookingService.cancelBooking(tempBooking.id, tempBooking.doctorId, tempBooking.calendarId, undefined, tempBooking.phone, tempBooking.date, tempBooking.time);
        botReply(
          "Am eliberat slotul anterior, haideți să alegem o dată nouă. Păstrăm datele de contact de la programarea anterioară?",
          ["Da", "Nu"],
          'edit_keep_details'
        );
      } else if (lowerInput.includes('anulează')) {
        botReply(
          `Sunteți sigur că doriți să anulați programarea pentru ${tempBooking.service} din data de ${formatDateForDisplay(tempBooking.date)} la ora ${tempBooking.time}?`,
          ["Da", "Nu"],
          'edit_cancel_confirm'
        );
      } else if (lowerInput.includes('da') || lowerInput.includes('corect')) {
        botReply(
          "Perfect. Ce doriți să faceți cu această programare?",
          ["Editează programarea", "Anulează programarea", "Meniu principal"]
        );
      } else if (lowerInput.includes('nu') || lowerInput.includes('greșit')) {
        botReply("Îmi pare rău. Vă rog să introduceți din nou numărul de telefon pentru a căuta din nou.", undefined, 'edit_search');
      } else {
        setStep('initial');
        botReply("Cu ce vă mai pot ajuta?", ["Vreau o programare", "Editare programare efectuată", "Întrebări frecvente"]);
      }
    }

    else if (step === 'edit_cancel_confirm') {
      if (lowerInput === 'da' || lowerInput.includes('da')) {
        await bookingService.cancelBooking(tempBooking.id, tempBooking.doctorId, tempBooking.calendarId, bookingData.email, tempBooking.phone, tempBooking.date, tempBooking.time);
        botReply(
          "Vă mulțumim, programarea a fost anulată, slotul orar este acum din nou disponibil.\n\nCu ce vă mai pot ajuta?",
          ["Vreau o programare", "Editare programare efectuată", "Întrebări frecvente"],
          'initial'
        );
      } else {
        botReply(
          "Am înțeles. Ce doriți să faceți cu această programare?",
          ["Editează programarea", "Anulează programarea", "Meniu principal"],
          'edit_confirm_details'
        );
      }
    }

    else if (step === 'edit_reschedule_date') {
      const validation = bookingService.validateDate(input);
      if (!validation.isValid) {
        botReply(validation.error || "Data nu este validă. Vă rugăm să încercați din nou (ex: 15 Aprilie).");
        return;
      }
      setTempBooking(prev => ({ ...prev, date: validation.formatted }));
      setIsTyping(true);
      try {
        const slots = await bookingService.getAvailableSlots(validation.iso!, bookingData.doctorId, bookingData.service);
        setIsTyping(false);
        botReply(`Verific disponibilitatea în calendarul medicului... Ce oră ați prefera pentru noua dată de ${validation.formatted}?`, slots, 'edit_reschedule_time');
      } catch (error) {
        setIsTyping(false);
        botReply(
          "A apărut o eroare de conexiune la verificarea calendarului. Vă rugăm să încercați din nou.",
          ["Încearcă din nou", "Meniu principal"],
          'edit_reschedule_date'
        );
      }
    }

    else if (step === 'edit_reschedule_time') {
      const updatedBooking = { ...tempBooking, time: input };
      try {
        setIsTyping(true);
        await bookingService.cancelBooking(tempBooking.id, tempBooking.doctorId, tempBooking.calendarId, undefined, tempBooking.phone, tempBooking.date, tempBooking.time);
        const result = await bookingService.createBooking({
          date: updatedBooking.isoDate || updatedBooking.date,
          displayDate: updatedBooking.date,
          time: updatedBooking.time,
          service: updatedBooking.service,
          firstName: updatedBooking.firstName,
          lastName: updatedBooking.lastName,
          phone: updatedBooking.phone,
          doctorId: updatedBooking.doctorId || bookingData.doctorId
        });
        setIsTyping(false);

        const assignedText = (result as any).assignedMessage ? `\n\n👨‍⚕️ ${(result as any).assignedMessage}` : '';

        botReply(
          `✅ Felicitări, ${updatedBooking.firstName} ${updatedBooking.lastName}! Programarea dumneavoastră a fost înregistrată cu succes la ${result.doctorName || bookingData.doctorName}, ${updatedBooking.date} la ora ${updatedBooking.time}.${assignedText}\n\n📱 Recepția a primit actualizarea, iar mesajul de confirmare a fost trimis pe WhatsApp.\n\nCu ce vă mai pot ajuta?`,
          ["Vreau o programare", "Editare programare efectuată", "Închide"],
          'confirmed'
        );
      } catch (error: any) {
        setIsTyping(false);
        botReply(
          `⚠️ Ne pare rău, dar a apărut o problemă: ${error.message || "Slotul a fost ocupat între timp"}. Vă rugăm să alegeți altă oră.`,
          ["Alege altă oră", "Meniu principal"],
          'edit_reschedule_date'
        );
      }
    }

    else if (step === 'confirmed') {
      if (lowerInput.includes('email')) {
        botReply("Vă rugăm să introduceți adresa de email unde doriți să primiți detaliile:", ["Anulează"]);
        setStep('email_request');
      } else if (lowerInput.includes('editare')) {
        botReply("Vă rog să introduceți numărul de telefon folosit la programare.", undefined, 'edit_search');
      } else if (lowerInput.includes('programare')) {
        setBookingData({});
        setStep('initial');
        botReply("Cu ce vă mai pot ajuta?", ["Vreau o programare", "Editare programare efectuată", "Întrebări frecvente"]);
      } else {
        botReply("Cu ce vă mai pot ajuta?", ["Vreau o programare", "Editare programare efectuată", "Sună Clinica", "Întrebări frecvente"], 'initial');
      }
    }

    else if (step === 'email_request') {
      if (lowerInput.includes('anulează')) {
        botReply("Am anulat trimiterea email-ului. Cu ce vă mai pot ajuta?", ["Vreau o programare", "Editare programare efectuată", "Închide"], 'confirmed');
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (emailRegex.test(input)) {
        setIsTyping(true);
        try {
          const dataToEmail = tempBooking || {
            firstName: bookingData.firstName,
            lastName: bookingData.lastName,
            date: bookingData.isoDate || bookingData.date,
            time: bookingData.time,
            service: bookingData.service,
            doctorName: bookingData.doctorName
          };

          await bookingService.sendEmailConfirmation(input, dataToEmail);
          setIsTyping(false);
          botReply(`Gata! Am trimis detaliile pe ${input}. Vă așteptăm cu drag!`, ["Vreau o programare", "Editare programare efectuată", "Închide"], 'confirmed');
        } catch (error) {
          setIsTyping(false);
          botReply("Ne pare rău, dar a apărut o eroare la trimiterea email-ului. Vă rugăm să verificați adresa și să încercați din nou.", ["Încearcă din nou", "Anulează"]);
        }
      } else {
        botReply("Vă rugăm să introduceți o adresă de email validă (ex: nume@exemplu.com).", ["Anulează"]);
      }
    }

    else if (step === 'call_confirm') {
      if (lowerInput === 'da_apeleaza') {
        const phone = clinicConfig?.clinicPhone || "0700 000 000";
        window.location.href = `tel:${phone.replace(/\s+/g, '')}`;
      } else {
        setStep('initial');
        botReply("Am revenit la meniul principal. Cu ce vă mai pot ajuta?", ["Vreau o programare", "Editare programare efectuată", "Sună Clinica", "Întrebări frecvente"]);
      }
    }
  };

  return (
    <div className="min-h-screen bg-white font-sans overflow-x-hidden">
      {/* Clinic Simulation Header */}
      <header className="bg-white border-b border-slate-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
              <Smartphone className="text-white w-6 h-6" />
            </div>
            <span className="text-2xl font-black tracking-tight text-slate-900">Beautiful<span className="text-blue-600">Smile</span></span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors">Servicii</a>
            <a href="#" className="text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors">Echipa</a>
            <a href="#" className="text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors">Prețuri</a>
            <a href="#" className="text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors">Contact</a>
            <button className="px-6 py-2.5 bg-blue-600 text-white rounded-full text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100">
              Programare Rapidă
            </button>
          </nav>
          <Link to="/" className="flex items-center gap-2 text-slate-400 hover:text-slate-900 transition-colors text-xs font-bold">
            <X className="w-4 h-4" />
            <span>Înapoi la DentalVoice</span>
          </Link>
        </div>
      </header>

      {/* Hero Section Simulation */}
      <section className="relative py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-full text-xs font-black uppercase tracking-widest mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-600"></span>
              </span>
              Clinica ta de încredere
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.1] tracking-tight">
              Zâmbetul tău, <br />
              <span className="text-blue-600">Prioritatea noastră.</span>
            </h1>
            <p className="text-slate-600 text-xl mb-10 leading-relaxed font-medium max-w-lg">
              Tehnologie de ultimă oră și o echipă de specialiști dedicați sănătății tale orale. Descoperă experiența Beautiful Smile.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-black hover:bg-blue-700 transition-all shadow-xl shadow-blue-100">
                Vezi Serviciile
              </button>
              <button className="px-8 py-4 bg-white text-slate-900 border-2 border-slate-100 rounded-2xl font-black hover:bg-slate-50 transition-all">
                Tur Virtual
              </button>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-square rounded-[3rem] overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=2070&auto=format&fit=crop" 
                alt="Dental Clinic" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -left-8 bg-white p-8 rounded-[2rem] shadow-2xl border border-slate-100 hidden lg:block">
              <div className="flex items-center gap-4 mb-4">
                <div className="flex -space-x-3">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white overflow-hidden">
                      <img src={`https://i.pravatar.cc/100?img=${i+10}`} alt="User" referrerPolicy="no-referrer" />
                    </div>
                  ))}
                </div>
                <div className="text-sm font-bold text-slate-900">+500 Pacienți fericiți</div>
              </div>
              <div className="flex gap-1">
                {[1,2,3,4,5].map(i => <div key={i} className="w-4 h-4 text-yellow-400 fill-current">★</div>)}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Floating Chatbot Simulation */}
      <div className="fixed bottom-8 right-8 z-[100]">
        {!isChatOpen ? (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsChatOpen(true)}
            className="w-16 h-16 bg-blue-600 text-white rounded-full shadow-2xl flex items-center justify-center relative group"
          >
            <Bot className="w-8 h-8" />
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
            <div className="absolute right-20 bg-white text-slate-900 px-4 py-2 rounded-xl shadow-xl border border-slate-100 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none font-bold text-sm">
              Bună! Te pot ajuta cu o programare?
            </div>
          </motion.button>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="w-[380px] h-[600px] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200"
          >
            {/* Header Chat */}
            <div className="bg-blue-600 p-4 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center relative">
                  <Bot className="w-6 h-6" />
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 border-2 border-blue-600 rounded-full"></div>
                </div>
                <div>
                  <div className="font-bold leading-none text-sm">Denti</div>
                  <div className="text-[10px] text-blue-100 mt-1 flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full"></div>
                    Activ acum
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsChatOpen(false)}
                className="p-2 hover:bg-white/10 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mesaje */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
              {messages.map((msg) => (
                <div key={msg.id} className={cn("flex flex-col", msg.type === 'user' ? "items-end" : "items-start")}>
                  <div className={cn(
                    "max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed shadow-sm",
                    msg.type === 'user' 
                      ? "bg-blue-600 text-white rounded-tr-none" 
                      : "bg-white text-slate-800 rounded-tl-none border border-slate-200"
                  )}>
                    {msg.text.split('\n').map((line, i) => <p key={i}>{line}</p>)}
                  </div>
                  
                  {msg.options && (
                    <div className="flex flex-wrap gap-2 mt-3 max-w-[90%]">
                      {msg.options.map((opt, i) => {
                        const label = typeof opt === 'string' ? opt : opt.label;
                        const href = typeof opt === 'object' ? (opt as any).href : undefined;
                        
                        if (href) {
                          return (
                            <a
                              key={i}
                              href={href}
                              className="px-3 py-1.5 bg-blue-600 text-white border border-blue-600 rounded-full text-xs font-semibold hover:bg-blue-700 transition-colors shadow-sm inline-flex items-center gap-1"
                            >
                              <Smartphone className="w-3 h-3" />
                              {label}
                            </a>
                          );
                        }
                        
                        return (
                          <button
                            key={i}
                            onClick={() => handleOptionClick(opt)}
                            className="px-3 py-1.5 bg-white border border-blue-200 text-blue-600 rounded-full text-xs font-semibold hover:bg-blue-50 transition-colors shadow-sm"
                          >
                            {label}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              ))}
              
              {isTyping && (
                <div className="flex items-start gap-2">
                  <div className="bg-white border border-slate-200 p-3 rounded-2xl rounded-tl-none shadow-sm">
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Zona de Input */}
            <div className="p-4 border-t border-slate-100 bg-white">
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleUserInput(inputValue);
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Scrie un mesaj..."
                  className="flex-1 bg-slate-100 border-none rounded-full px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <button 
                  type="submit"
                  disabled={!inputValue.trim()}
                  className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-700 transition-colors"
                >
                  <Send className="w-5 h-5" />
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
